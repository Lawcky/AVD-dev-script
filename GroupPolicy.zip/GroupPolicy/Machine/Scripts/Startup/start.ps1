cmdkey.exe /add:avdfslogixvanves.file.core.windows.net /user:localhost\avdfslogixvanves /pass:EQPo3Y2oYi0w5vxueRTzZdDtUWEm9Wwm2++F2y0imL5VEHB+jyANFPsvGn8M4CK5A/bf7bcb956f+AStk0fd1Q==
